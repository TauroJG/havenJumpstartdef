extends CharacterBody2D


const XPOrbScene:= preload("res://scenes/XPOrb.tscn")
const Gravity:= 1100.0
const max_fall_speed:= 900.0
const xp_per_hit:=5
	
@export var hits_to_kill:int=1
var health:int
var move_speed: float= 60.0
var direction: int=1
	
@onready var visual: Polygon2D= $Visual
func _ready() -> void:
	health= hits_to_kill
	direction=1 if randi() %2==0 else -1
	_update_color()

func _physics_process(delta: float) -> void:
	health -= amount
	if health <= 0:
		die()
	else:
		_update_color()
		_bump()
func _upddate_color() -> void:
	var ponmi := clampi(health, 1, 4)
	match ponmi:	
		1:
			visual.color= Color(0.30, 0.85, 0.35)
		2:
			visual.color= Color(0.95, 0)
